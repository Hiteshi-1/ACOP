import React from "react";

export default function StatCard({
  icon,
  title,
  value,
  subtitle,
  iconClass,
  valueClass,
}) {
  return (
    <div className="group rounded-2xl border border-slate-700/80 bg-gradient-to-br from-[#16233b] to-[#101a2d] p-5 shadow-[0_10px_30px_rgba(0,0,0,0.16)] transition hover:-translate-y-0.5 hover:border-blue-500/50">
      <div className="flex items-center gap-4">
        <div
          className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-xl text-2xl ${iconClass}`}
        >
          {icon}
        </div>

        <div>
          <p className="mb-1 text-xs font-medium text-slate-400">{title}</p>

          <p
            className={`text-3xl font-bold leading-none ${
              valueClass || "text-white"
            }`}
          >
            {value}
          </p>

          <p className="mt-2 text-xs font-semibold text-slate-400">
            {subtitle}
          </p>
        </div>
      </div>
    </div>
  );
}