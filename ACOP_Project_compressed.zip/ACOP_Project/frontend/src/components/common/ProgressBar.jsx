function ProgressBar({
  title,
  value,
  color,
}) {

return(

<div style={{marginBottom:"18px"}}>

<div style={{
display:"flex",
justifyContent:"space-between",
marginBottom:"8px"
}}>

<span>{title}</span>

<span>{value}%</span>

</div>

<div
style={{
width:"100%",
height:"8px",
background:"#1E293B",
borderRadius:"20px"
}}
>

<div
style={{
width:`${value}%`,
height:"100%",
background:color,
borderRadius:"20px"
}}
>

</div>

</div>

</div>

)

}

export default ProgressBar;