import "./overview.css";

function OverviewCard({
  title,
  value,
  subtitle,
  icon,
  color
}) {

  return (

    <div className="overview-card">

      <div
        className="overview-icon"
        style={{background:color}}
      >
        {icon}
      </div>

      <div className="overview-content">

        <h4>{title}</h4>

        <h2>{value}</h2>

        <span>{subtitle}</span>

      </div>

    </div>

  );

}

export default OverviewCard;