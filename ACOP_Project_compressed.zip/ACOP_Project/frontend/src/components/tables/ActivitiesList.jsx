import React from "react";
import "./table.css";

const activities = [
  {
    text: "Auto scaling triggered for user-service",
    time: "5 min ago",
  },
  {
    text: "Pod restart executed for payment-service",
    time: "11 min ago",
  },
  {
    text: "Backup completed for database",
    time: "30 min ago",
  },
  {
    text: "Security scan completed",
    time: "1 hr ago",
  },
];

function ActivitiesList() {
  return (
    <div className="activities-card">
      <div className="section-header">
        <div>
          <h2>Recent Activities</h2>
          <p>Latest system activities</p>
        </div>
      </div>

      <div className="activities-list">
        {activities.map((activity, index) => (
          <div className="activity-row" key={index}>
            <div className="activity-left">
              <span className="check-icon">✓</span>
              <span>{activity.text}</span>
            </div>

            <span className="activity-time">{activity.time}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ActivitiesList;