import React from "react";
import "./table.css";

const incidents = [
  {
    incident: "Database connection timeout",
    severity: "High",
    status: "Resolved",
    time: "10 min ago",
    service: "payment-service",
  },
  {
    incident: "High memory usage detected",
    severity: "Medium",
    status: "Investigating",
    time: "25 min ago",
    service: "user-service",
  },
  {
    incident: "Pod restarted automatically",
    severity: "Low",
    status: "Resolved",
    time: "1 hr ago",
    service: "inventory-service",
  },
];

function IncidentTable() {
  return (
    <div className="incidents-card">
      <div className="section-header">
        <div>
          <h2>Recent Incidents</h2>
          <p>Manage and monitor recent incidents</p>
        </div>

        <button className="view-all-btn">View All</button>
      </div>

      <div className="table-wrapper">
        <table className="incident-table">
          <thead>
            <tr>
              <th>Incident</th>
              <th>Severity</th>
              <th>Status</th>
              <th>Time</th>
              <th>Service</th>
            </tr>
          </thead>

          <tbody>
            {incidents.map((item, index) => (
              <tr key={index}>
                <td>{item.incident}</td>

                <td>
                  <span
                    className={`badge severity-${item.severity.toLowerCase()}`}
                  >
                    {item.severity}
                  </span>
                </td>

                <td>
                  <span
                    className={`badge status-${item.status
                      .toLowerCase()
                      .replace(" ", "-")}`}
                  >
                    {item.status}
                  </span>
                </td>

                <td>{item.time}</td>

                <td>{item.service}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default IncidentTable;