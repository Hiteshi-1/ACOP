function MemoryChart() {
  return (
    <div className="chart-card memory">
      <div className="chart-header">
        <h3>Memory Usage</h3>
        <strong>68%</strong>
      </div>

      <div className="fake-chart">
        ╱╲╱╲___╱╲╱╲___╱╲╱╲
      </div>

      <div className="chart-axis">
        <span>00:00</span>
        <span>06:00</span>
        <span>12:00</span>
        <span>18:00</span>
        <span>24:00</span>
      </div>
    </div>
  );
}

export default MemoryChart;