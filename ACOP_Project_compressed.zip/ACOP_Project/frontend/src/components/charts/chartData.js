export const cpuData = [
  { name: "Mon", value: 35 },
  { name: "Tue", value: 48 },
  { name: "Wed", value: 62 },
  { name: "Thu", value: 51 },
  { name: "Fri", value: 78 },
  { name: "Sat", value: 60 },
  { name: "Sun", value: 70 },
];

export const memoryData = [
  { name: "Mon", value: 55 },
  { name: "Tue", value: 58 },
  { name: "Wed", value: 64 },
  { name: "Thu", value: 72 },
  { name: "Fri", value: 68 },
  { name: "Sat", value: 75 },
  { name: "Sun", value: 81 },
];

export const networkData = [
  { name: "Mon", value: 250 },
  { name: "Tue", value: 420 },
  { name: "Wed", value: 380 },
  { name: "Thu", value: 560 },
  { name: "Fri", value: 510 },
  { name: "Sat", value: 610 },
  { name: "Sun", value: 700 },
];

export const storageData = [
  { name: "Used", value: 72 },
  { name: "Free", value: 28 },
];