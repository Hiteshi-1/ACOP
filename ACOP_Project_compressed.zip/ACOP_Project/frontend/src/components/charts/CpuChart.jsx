import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip,
} from "recharts";

const data = [
  { time: "00:00", value: 42 },
  { time: "04:00", value: 58 },
  { time: "08:00", value: 45 },
  { time: "12:00", value: 62 },
  { time: "16:00", value: 48 },
  { time: "20:00", value: 68 },
  { time: "24:00", value: 42 },
];

function CPUChart() {
  return (
    <div className="chart-wrapper">

      <div className="chart-header">
        <span className="chart-title">
          CPU Usage
        </span>

        <span className="chart-value">
          42%
        </span>
      </div>

      <div className="chart-container">

        <ResponsiveContainer width="100%" height="100%">

          <LineChart data={data}>

            <XAxis
              dataKey="time"
              tick={{ fontSize: 8 }}
              axisLine={false}
              tickLine={false}
            />

            <YAxis
              hide
            />

            <Tooltip />

            <Line
              type="monotone"
              dataKey="value"
              stroke="#3b82f6"
              strokeWidth={2}
              dot={false}
            />

          </LineChart>

        </ResponsiveContainer>

      </div>

    </div>
  );
}

export default CPUChart;