import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
} from "recharts";

import { storageData } from "./chartData";

const COLORS = ["#3B82F6", "#1E293B"];

function StorageChart() {
  return (
    <ResponsiveContainer width="100%" height={250}>
      <PieChart>
        <Pie
          data={storageData}
          dataKey="value"
          outerRadius={90}
          innerRadius={55}
        >
          {storageData.map((entry, index) => (
            <Cell
              key={index}
              fill={COLORS[index % COLORS.length]}
            />
          ))}
        </Pie>

        <Tooltip />
      </PieChart>
    </ResponsiveContainer>
  );
}

export default StorageChart;