import {
  AreaChart,
  Area,
  ResponsiveContainer,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";

import { networkData } from "./chartData";

function NetworkChart() {
  return (
    <ResponsiveContainer width="100%" height={250}>
      <AreaChart data={networkData}>
        <defs>
          <linearGradient id="networkFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.8} />
            <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0.1} />
          </linearGradient>
        </defs>

        <CartesianGrid stroke="#1E293B" />
        <XAxis dataKey="name" stroke="#94A3B8" />
        <YAxis stroke="#94A3B8" />
        <Tooltip />

        <Area
          type="monotone"
          dataKey="value"
          stroke="#8B5CF6"
          fill="url(#networkFill)"
          strokeWidth={3}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export default NetworkChart;