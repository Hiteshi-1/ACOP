import React from "react";
import {
  FiBell,
  FiChevronDown,
  FiMoon,
  FiRefreshCw,
  FiSearch,
} from "react-icons/fi";

export default function Header() {
  return (
    <header className="flex h-[72px] items-center justify-between border-b border-slate-800/80 bg-[#0b1221]/80 px-8">
      {/* Search */}
      <div className="relative w-[360px]">
        <FiSearch
          size={17}
          className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500"
        />

        <input
          type="text"
          placeholder="Search (Ctrl + K)"
          className="h-11 w-full rounded-xl border border-slate-700 bg-slate-900/70 pl-11 pr-4 text-sm text-white outline-none placeholder:text-slate-500 focus:border-blue-500"
        />
      </div>

      {/* Actions */}
      <div className="flex items-center gap-5">
        <button className="relative text-slate-400 transition hover:text-white">
          <FiBell size={20} />

          <span className="absolute -right-2 -top-2 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white">
            1
          </span>
        </button>

        <button className="text-slate-400 transition hover:text-white">
          <FiMoon size={20} />
        </button>

        <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-slate-700 bg-gradient-to-br from-orange-300 to-orange-600 font-semibold text-white">
          A
        </div>
      </div>
    </header>
  );
}