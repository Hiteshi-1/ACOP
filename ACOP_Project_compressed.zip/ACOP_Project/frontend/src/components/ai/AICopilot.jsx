import "./ai.css";
import { FaRobot } from "react-icons/fa";

function AICopilot() {
  return (
    <div className="ai-panel">

      <div className="ai-header">

        <div className="robot">

          <FaRobot />

        </div>

        <div>

          <h2>AI SRE Copilot</h2>

          <p>Powered by Llama 3.2</p>

        </div>

      </div>

      <div className="recommendation">

        <h4>Recommendation</h4>

        <p>
          High CPU utilization detected on
          <strong> Kubernetes Cluster-02</strong>.
          Scale deployment by 2 replicas.
        </p>

      </div>

      <div className="recommendation">

        <h4>Root Cause</h4>

        <p>

          Traffic spike detected from API Gateway.

        </p>

      </div>

      <button>

        Apply Recommendation

      </button>

    </div>
  );
}

export default AICopilot;