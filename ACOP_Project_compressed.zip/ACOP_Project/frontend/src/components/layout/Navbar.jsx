import React from "react";

function Navbar() {
  return (
    <header className="navbar">

      <div className="navbar-search">

        <input
          type="text"
          placeholder="Search (Ctrl + K)"
        />

      </div>

      <div className="navbar-actions">

        <span>🔔</span>

        <span>🌙</span>

        <span>Last 24 Hours</span>

        <span>⟳</span>

      </div>

    </header>
  );
}

export default Navbar;