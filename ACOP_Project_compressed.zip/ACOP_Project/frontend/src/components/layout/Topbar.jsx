import React from "react";

import {
  MdSearch,
  MdNotificationsNone,
  MdDarkMode,
} from "react-icons/md";

import "./Topbar.css";

function Topbar() {
  return (
    <header className="topbar">

      <div className="search-box">
        <MdSearch />

        <input
          type="text"
          placeholder="Search (Ctrl + K)"
        />
      </div>

      <div className="topbar-actions">

        <div className="notification">
          <MdNotificationsNone />
          <span>1</span>
        </div>

        <MdDarkMode className="topbar-icon" />

        <div className="topbar-avatar">
          A
        </div>

      </div>

    </header>
  );
}

export default Topbar;