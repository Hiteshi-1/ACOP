import React from "react";
import { NavLink } from "react-router-dom";
import "./Sidebar.css";

function Sidebar() {
  const menuItems = [
    { name: "Dashboard", path: "/dashboard", icon: "▦" },
    { name: "AI SRE Copilot", path: "/ai-sre-copilot", icon: "✦" },

    // NEW PAGE
    { name: "AI Code Debugger", path: "/ai-code-debugger", icon: "🐞" },

    { name: "Incidents", path: "/incidents", icon: "⚠" },
    { name: "Predictive Failures", path: "/predictive-failures", icon: "⌁" },
    { name: "Kubernetes", path: "/kubernetes", icon: "◆" },
    { name: "Security Center", path: "/security", icon: "♢" },
    { name: "Knowledge Base", path: "/knowledge-base", icon: "▤" },
    { name: "Reports", path: "/reports", icon: "▥" },
    { name: "Settings", path: "/settings", icon: "⚙" },
  ];

  return (
    <aside className="sidebar">

      <div className="sidebar-brand">
        <div className="brand-icon">✦</div>

        <div>
          <h2>ACOP</h2>
          <p>
            Autonomous Cloud
            <br />
            Operations Platform
          </p>
        </div>
      </div>

      <nav className="sidebar-nav">

        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `sidebar-link ${isActive ? "active" : ""}`
            }
          >
            <span className="sidebar-icon">
              {item.icon}
            </span>

            <span>
              {item.name}
            </span>
          </NavLink>
        ))}

      </nav>

      <div className="admin-card">

        <div className="admin-avatar">
          A
        </div>

        <div className="admin-info">
          <strong>Aarti Admin</strong>
          <span>aarti@acop.com</span>
        </div>

        <div className="online-dot"></div>

      </div>

    </aside>
  );
}

export default Sidebar;