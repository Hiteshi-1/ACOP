import React from "react";

function MetricCard({
  icon,
  title,
  value,
  subtitle,
  type = "default",
  onClick
}) {
  return (
    <div
      className={`metric-card ${type}`}
      onClick={onClick}
    >
      <div className="metric-card-top">

        <div className="metric-icon">
          {icon}
        </div>

        <div className="metric-title">
          {title}
        </div>

      </div>

      <div className="metric-value">
        {value}
      </div>

      <div className="metric-subtitle">
        {subtitle}
      </div>

    </div>
  );
}

export default MetricCard;