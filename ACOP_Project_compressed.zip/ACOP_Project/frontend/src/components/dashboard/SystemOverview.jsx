import OverviewCard from "../widgets/OverviewCard";

import {
FaServer,
FaCloud,
FaDatabase,
FaRobot
} from "react-icons/fa";

function SystemOverview(){

return(

<div
className="overview-grid"
>

<OverviewCard

title="Cloud Nodes"

value="24"

subtitle="Running Normally"

icon={<FaCloud/>}

color="#2563EB"

/>

<OverviewCard

title="AI Predictions"

value="15"

subtitle="Updated 2 min ago"

icon={<FaRobot/>}

color="#9333EA"

/>

<OverviewCard

title="Databases"

value="08"

subtitle="Healthy"

icon={<FaDatabase/>}

color="#10B981"

/>

<OverviewCard

title="Servers"

value="42"

subtitle="98% Available"

icon={<FaServer/>}

color="#F97316"

/>

</div>

)

}

export default SystemOverview;