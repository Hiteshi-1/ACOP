import React from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export default function ChartCard({
  title,
  value,
  data,
  lineColor,
  gradientId,
  fillGradient,
}) {
  return (
    <div className="rounded-2xl border border-slate-700/80 bg-gradient-to-br from-[#16233b] to-[#101a2d] p-5 shadow-[0_10px_30px_rgba(0,0,0,0.16)]">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-white">{title}</h3>

        <span
          className="text-sm font-bold"
          style={{ color: lineColor }}
        >
          {value}
        </span>
      </div>

      <div className="h-[190px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            data={data}
            margin={{
              top: 8,
              right: 4,
              left: -25,
              bottom: 0,
            }}
          >
            <defs>
              <linearGradient
                id={gradientId}
                x1="0"
                y1="0"
                x2="0"
                y2="1"
              >
                <stop
                  offset="0%"
                  stopColor={lineColor}
                  stopOpacity={0.22}
                />

                <stop
                  offset="100%"
                  stopColor={lineColor}
                  stopOpacity={0}
                />
              </linearGradient>
            </defs>

            <CartesianGrid
              stroke="#33445f"
              strokeDasharray="3 5"
              vertical={false}
              opacity={0.65}
            />

            <XAxis
              dataKey="time"
              tick={{
                fill: "#94a3b8",
                fontSize: 10,
              }}
              axisLine={false}
              tickLine={false}
            />

            <YAxis
              domain={[0, 100]}
              ticks={[0, 50, 100]}
              tickFormatter={(value) => `${value}%`}
              tick={{
                fill: "#94a3b8",
                fontSize: 10,
              }}
              axisLine={false}
              tickLine={false}
            />

            <Tooltip
              contentStyle={{
                background: "#111c31",
                border: "1px solid #33445f",
                borderRadius: "10px",
                color: "#fff",
              }}
            />

            <Line
              type="monotone"
              dataKey="value"
              stroke={lineColor}
              strokeWidth={3}
              dot={false}
              activeDot={{ r: 5 }}
              fill={fillGradient ? `url(#${gradientId})` : "none"}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
<div className="chart-wrapper">
  <ResponsiveContainer width="100%" height="100%">
    <LineChart data={data}>
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="time" />
      <YAxis />
      <Tooltip />
      <Line
        type="monotone"
        dataKey="value"
        stroke="#38bdf8"
        strokeWidth={2}
        dot={false}
      />
    </LineChart>
  </ResponsiveContainer>
</div>