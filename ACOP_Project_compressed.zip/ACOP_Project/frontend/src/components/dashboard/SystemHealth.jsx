import ProgressBar from "../common/ProgressBar";

function SystemHealth(){

return(

<div
style={{
background:"#111827",
padding:"22px",
borderRadius:"18px",
border:"1px solid #243244"
}}
>

<h2
style={{
marginBottom:"25px"
}}
>

System Health

</h2>

<ProgressBar

title="CPU"

value={78}

color="#3B82F6"

/>

<ProgressBar

title="Memory"

value={64}

color="#22C55E"

/>

<ProgressBar

title="Storage"

value={83}

color="#F59E0B"

/>

<ProgressBar

title="Network"

value={58}

color="#8B5CF6"

/>

</div>

)

}

export default SystemHealth;