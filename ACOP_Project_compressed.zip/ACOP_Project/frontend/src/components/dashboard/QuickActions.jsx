import "./dashboardWidgets.css";

function QuickActions(){

return(

<div className="widget">

<h2>Quick Actions</h2>

<button className="action-btn">

Restart Kubernetes Pod

</button>

<button className="action-btn">

Run Security Scan

</button>

<button className="action-btn">

Generate RCA Report

</button>

<button className="action-btn">

Backup Database

</button>

</div>

)

}

export default QuickActions;