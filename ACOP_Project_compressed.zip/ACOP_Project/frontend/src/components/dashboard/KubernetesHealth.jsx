import "./dashboardWidgets.css";

function KubernetesHealth() {

return (

<div className="widget">

<h2>Kubernetes Health</h2>

<div className="circle">

<span>98%</span>

</div>

<div className="health-list">

<div>

<span>Healthy Pods</span>

<strong>248</strong>

</div>

<div>

<span>Failed Pods</span>

<strong>4</strong>

</div>

<div>

<span>Namespaces</span>

<strong>15</strong>

</div>

</div>

</div>

);

}

export default KubernetesHealth;