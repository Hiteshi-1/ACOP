import React from "react";

function RecentActivities() {
  return (
    <div className="dashboard-panel">

      <div className="panel-header">
        <h2>Recent Activities</h2>

        <button>
          View All
        </button>
      </div>

      <div className="activity-list">

        <div className="activity-item">
          <span className="activity-dot"></span>

          <div>
            <strong>Deployment completed</strong>
            <p>Production environment</p>
          </div>

          <small>
            5 min ago
          </small>
        </div>

        <div className="activity-item">
          <span className="activity-dot"></span>

          <div>
            <strong>Security scan completed</strong>
            <p>All systems checked</p>
          </div>

          <small>
            20 min ago
          </small>
        </div>

        <div className="activity-item">
          <span className="activity-dot"></span>

          <div>
            <strong>New Kubernetes pod created</strong>
            <p>Backend cluster</p>
          </div>

          <small>
            1 hour ago
          </small>
        </div>

      </div>

    </div>
  );
}

export default RecentActivities;