import React from "react";

function RecentIncidents() {
  return (
    <div className="dashboard-panel">

      <div className="panel-header">
        <h2>Recent Incidents</h2>

        <button>
          View All
        </button>
      </div>

      <div className="incident-list">

        <div className="incident-item">
          <div>
            <strong>High CPU Usage</strong>
            <span>Production Server</span>
          </div>

          <span className="status critical">
            Critical
          </span>
        </div>

        <div className="incident-item">
          <div>
            <strong>Pod Restart Detected</strong>
            <span>Backend Service</span>
          </div>

          <span className="status warning">
            Warning
          </span>
        </div>

        <div className="incident-item">
          <div>
            <strong>Memory Threshold</strong>
            <span>API Service</span>
          </div>

          <span className="status resolved">
            Resolved
          </span>
        </div>

      </div>

    </div>
  );
}

export default RecentIncidents;