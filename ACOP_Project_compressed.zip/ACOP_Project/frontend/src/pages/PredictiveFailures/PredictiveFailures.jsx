import React from "react";
import {
  TrendingUp,
  AlertTriangle,
  Clock,
  Server,
} from "lucide-react";

import "./PredictiveFailures.css";

const failures = [
  {
    server: "worker-node-02",
    risk: "High",
    title: "Memory Exhaustion",
    probability: "94%",
    time: "20 min",
  },
  {
    server: "worker-node-04",
    risk: "Medium",
    title: "Disk Failure",
    probability: "72%",
    time: "1 hr 10 min",
  },
  {
    server: "db-node-01",
    risk: "Medium",
    title: "CPU Overload",
    probability: "65%",
    time: "2 hr 30 min",
  },
];

function PredictiveFailures() {
  return (
    <div className="prediction-page">

      <div className="prediction-header">
        <div>
          <h1>Predictive Failures</h1>
          <p>ML-based failure prediction and forecasting</p>
        </div>

        <button>View All Predictions</button>
      </div>

      <div className="prediction-cards">

        {failures.map((failure, index) => (

          <div className="prediction-card" key={index}>

            <div className="prediction-info">

              <span>Server: {failure.server}</span>

              <strong className={failure.risk.toLowerCase()}>
                Risk: {failure.risk}
              </strong>

              <h3>{failure.title}</h3>

            </div>

            <div className="probability">
              <span>Probability</span>
              <strong>{failure.probability}</strong>
            </div>

            <div className="prediction-time">
              <span>Estimated Time</span>
              <strong>{failure.time}</strong>
            </div>

            <button className="details-btn">
              View Details
            </button>

          </div>

        ))}

      </div>

    </div>
  );
}

export default PredictiveFailures;