import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { FiLock, FiMail, FiEye, FiEyeOff } from "react-icons/fi";
import "./Login.css";

const Login = () => {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();

    if (!email || !password) {
      setError("Please enter email and password");
      return;
    }

    // Demo login
    if (email === "aarti@acop.com" && password === "admin123") {
      localStorage.setItem("isLoggedIn", "true");
      navigate("/dashboard");
    } else {
      setError("Invalid email or password");
    }
  };

  return (
    <div className="login-page">
      <div className="login-container">

        {/* LEFT SECTION */}
        <div className="login-brand">
          <div className="brand-logo">✦</div>

          <h1>ACOP</h1>

          <p>
            Autonomous Cloud<br />
            Operations Platform
          </p>

          <div className="brand-description">
            Intelligent cloud operations powered by automation,
            monitoring, and AI-driven insights.
          </div>
        </div>

        {/* RIGHT SECTION */}
        <div className="login-card">

          <div className="login-header">
            <div className="login-icon">
              <FiLock />
            </div>

            <h2>Welcome Back</h2>

            <p>
              Sign in to access your cloud operations dashboard
            </p>
          </div>

          <form onSubmit={handleLogin}>

            <div className="input-group">
              <label>Email Address</label>

              <div className="input-wrapper">
                <FiMail />

                <input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div className="input-group">
              <label>Password</label>

              <div className="input-wrapper">
                <FiLock />

                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />

                <button
                  type="button"
                  className="password-toggle"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <FiEyeOff /> : <FiEye />}
                </button>
              </div>
            </div>

            {error && (
              <div className="login-error">
                {error}
              </div>
            )}

            <div className="login-options">
              <label>
                <input type="checkbox" />
                Remember me
              </label>

              <button type="button">
                Forgot Password?
              </button>
            </div>

            <button
              type="submit"
              className="login-button"
            >
              Sign In
            </button>

          </form>

          <div className="demo-login">
            <p>Demo Credentials</p>

            <span>
              Email: aarti@acop.com
            </span>

            <span>
              Password: admin123
            </span>
          </div>

        </div>

      </div>
    </div>
  );
};

export default Login;