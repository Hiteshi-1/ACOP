import React from "react";
import {
  AlertTriangle,
  Search,
  Plus,
} from "lucide-react";

import "./Incidents.css";

const incidents = [
  ["Database connection timeout", "High", "Open", "payment-service", "2 min ago"],
  ["High memory usage detected", "Medium", "Investigating", "user-service", "10 min ago"],
  ["Pod crashed unexpectedly", "Critical", "Open", "order-service", "15 min ago"],
  ["Disk space running low", "Low", "Resolved", "storage-service", "30 min ago"],
  ["API response time high", "Medium", "Resolved", "gateway-service", "1 hr ago"],
];

function Incidents() {
  return (
    <div className="incidents-page">

      <div className="incidents-header">
        <div>
          <h1>Incidents</h1>
          <p>Manage and monitor all incidents</p>
        </div>

        <button className="new-incident">
          <Plus size={16} />
          New Incident
        </button>
      </div>

      <div className="incident-filters">

        <div className="search-input">
          <Search size={16} />
          <input placeholder="Search incidents..." />
        </div>

        <select>
          <option>All Severity</option>
          <option>High</option>
          <option>Medium</option>
          <option>Low</option>
        </select>

        <select>
          <option>All Status</option>
          <option>Open</option>
          <option>Resolved</option>
        </select>

      </div>

      <div className="incident-table">

        <table>

          <thead>
            <tr>
              <th>Incident</th>
              <th>Severity</th>
              <th>Status</th>
              <th>Service</th>
              <th>Time</th>
            </tr>
          </thead>

          <tbody>
            {incidents.map((item, index) => (
              <tr key={index}>
                <td>{item[0]}</td>
                <td>
                  <span className={`incident-badge ${item[1].toLowerCase()}`}>
                    <AlertTriangle size={12} />
                    {item[1]}
                  </span>
                </td>
                <td>
                  <span className="incident-status">
                    {item[2]}
                  </span>
                </td>
                <td>{item[3]}</td>
                <td>{item[4]}</td>
              </tr>
            ))}
          </tbody>

        </table>

      </div>

    </div>
  );
}

export default Incidents;