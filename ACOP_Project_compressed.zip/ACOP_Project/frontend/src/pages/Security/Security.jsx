import React from "react";
import "./Security.css";

function Security() {
  return (
    <div className="security-page">

      {/* HEADER */}
      <div className="security-header">
        <div>
          <h1>Security Center</h1>
          <p>Monitor and respond to security threats</p>
        </div>

        <button className="security-primary-btn">
          Run Security Scan
        </button>
      </div>


      {/* SECURITY SUMMARY */}
      <section className="security-summary-grid">

        <div className="security-summary-card threat-level-card">
          <div className="security-card-icon orange">
            🛡
          </div>

          <div>
            <span>Threat Level</span>
            <strong>Medium</strong>
          </div>
        </div>


        <div className="security-summary-card">
          <div className="security-card-icon blue">
            ☷
          </div>

          <div>
            <span>Total Threats</span>
            <strong>12</strong>
          </div>
        </div>


        <div className="security-summary-card">
          <div className="security-card-icon red">
            ⚠
          </div>

          <div>
            <span>Active Threats</span>
            <strong>3</strong>
          </div>
        </div>


        <div className="security-summary-card">
          <div className="security-card-icon green">
            ✓
          </div>

          <div>
            <span>Resolved Threats</span>
            <strong>9</strong>
          </div>
        </div>

      </section>


      {/* THREATS TABLE */}
      <section className="security-panel">

        <div className="security-panel-header">
          <div>
            <h2>Security Threats</h2>
            <p>Recent security events detected in your infrastructure</p>
          </div>

          <button className="view-all-btn">
            View All Threats
          </button>
        </div>


        <div className="security-table-wrapper">

          <table className="security-table">

            <thead>
              <tr>
                <th>Threat</th>
                <th>Severity</th>
                <th>Status</th>
                <th>Source</th>
                <th>Time</th>
              </tr>
            </thead>

            <tbody>

              <tr>
                <td>Brute force attack detected</td>

                <td>
                  <span className="security-badge high">
                    ▲ High
                  </span>
                </td>

                <td>
                  <span className="security-badge active">
                    ● Active
                  </span>
                </td>

                <td>192.168.1.10</td>

                <td>5 min ago</td>
              </tr>


              <tr>
                <td>Malware detected in container</td>

                <td>
                  <span className="security-badge high">
                    ▲ High
                  </span>
                </td>

                <td>
                  <span className="security-badge active">
                    ● Active
                  </span>
                </td>

                <td>pod: evil-pod</td>

                <td>15 min ago</td>
              </tr>


              <tr>
                <td>Unauthorized login attempt</td>

                <td>
                  <span className="security-badge medium">
                    ▲ Medium
                  </span>
                </td>

                <td>
                  <span className="security-badge investigating">
                    ◉ Investigating
                  </span>
                </td>

                <td>10.0.0.5</td>

                <td>25 min ago</td>
              </tr>

            </tbody>

          </table>

        </div>

      </section>


      {/* SECURITY ANALYSIS */}
      <section className="security-bottom-grid">

        <div className="security-panel">

          <div className="security-panel-header">
            <div>
              <h2>Security Overview</h2>
              <p>Current protection status</p>
            </div>
          </div>


          <div className="security-progress-list">

            <div className="security-progress-item">
              <div>
                <span>Network Security</span>
                <strong>96%</strong>
              </div>

              <div className="progress-bar">
                <div style={{ width: "96%" }}></div>
              </div>
            </div>


            <div className="security-progress-item">
              <div>
                <span>Container Security</span>
                <strong>91%</strong>
              </div>

              <div className="progress-bar">
                <div style={{ width: "91%" }}></div>
              </div>
            </div>


            <div className="security-progress-item">
              <div>
                <span>Access Control</span>
                <strong>98%</strong>
              </div>

              <div className="progress-bar">
                <div style={{ width: "98%" }}></div>
              </div>
            </div>

          </div>

        </div>


        <div className="security-panel">

          <div className="security-panel-header">
            <div>
              <h2>Recent Security Activity</h2>
              <p>Latest security events</p>
            </div>
          </div>


          <div className="security-activity-list">

            <div className="security-activity">
              <span className="activity-dot red"></span>
              <div>
                <strong>Brute force attack detected</strong>
                <small>5 minutes ago</small>
              </div>
            </div>


            <div className="security-activity">
              <span className="activity-dot orange"></span>
              <div>
                <strong>Suspicious login attempt</strong>
                <small>18 minutes ago</small>
              </div>
            </div>


            <div className="security-activity">
              <span className="activity-dot green"></span>
              <div>
                <strong>Security scan completed</strong>
                <small>1 hour ago</small>
              </div>
            </div>

          </div>

        </div>

      </section>

    </div>
  );
}

export default Security;