import React from "react";
import "./AISRECopilot.css";

function AISRECopilot() {
  return (
    <div className="ai-sre-page">

      {/* HEADER */}
      <div className="ai-sre-header">

        <div>
          <div className="breadcrumb">
            Operations <span>/</span> AI SRE Copilot
          </div>

          <h1>AI SRE Copilot</h1>

          <p>
            Intelligent assistance for cloud operations, incident analysis,
            and automated remediation
          </p>
        </div>

        <div className="header-actions">
          <button className="time-button">
            Last 24 Hours ▾
          </button>

          <button className="refresh-button">
            ↻
          </button>
        </div>

      </div>


      {/* KPI CARDS */}
      <div className="ai-kpi-grid">

        <div className="ai-kpi-card blue-card">

          <div className="kpi-top">
            <span className="kpi-icon blue-icon">✦</span>
            <span className="trend positive">+12%</span>
          </div>

          <h3>AI Analyses</h3>

          <strong>248</strong>

          <p>Completed this month</p>

        </div>


        <div className="ai-kpi-card purple-card">

          <div className="kpi-top">
            <span className="kpi-icon purple-icon">⌕</span>
            <span className="trend positive">+8%</span>
          </div>

          <h3>Root Causes Found</h3>

          <strong>186</strong>

          <p>Successfully identified</p>

        </div>


        <div className="ai-kpi-card green-card">

          <div className="kpi-top">
            <span className="kpi-icon green-icon">✓</span>
            <span className="trend positive">94%</span>
          </div>

          <h3>Resolution Rate</h3>

          <strong>92%</strong>

          <p>AI-assisted resolution</p>

        </div>


        <div className="ai-kpi-card orange-card">

          <div className="kpi-top">
            <span className="kpi-icon orange-icon">⚡</span>
            <span className="trend positive">-24%</span>
          </div>

          <h3>MTTR Reduction</h3>

          <strong>38%</strong>

          <p>Average improvement</p>

        </div>

      </div>


      {/* MAIN AI COPILOT AREA */}
      <div className="ai-main-grid">

        {/* AI COPILOT */}
        <div className="ai-copilot-panel">

          <div className="panel-header">

            <div className="panel-title">

              <div className="large-panel-icon blue-panel-icon">
                ✦
              </div>

              <div>
                <h2>AI Operations Copilot</h2>

                <p>
                  Your intelligent assistant for cloud operations
                </p>
              </div>

            </div>

            <span className="status-online">
              <span></span>
              Online
            </span>

          </div>


          {/* AI ASSISTANT */}
          <div className="assistant-box">

            <div className="assistant-avatar">
              ✦
            </div>

            <div className="assistant-content">

              <div className="assistant-name">
                AI SRE Assistant
                <span>Just now</span>
              </div>

              <p>
                Hello Aarti! I am ready to help you analyze incidents,
                troubleshoot infrastructure problems, and optimize your
                cloud environment.
              </p>

            </div>

          </div>


          {/* INPUT */}
          <div className="ai-input-box">

            <input
              type="text"
              placeholder="Ask about your cloud infrastructure..."
            />

            <button>
              Send ✦
            </button>

          </div>


          {/* QUICK ACTIONS */}
          <div className="quick-actions">

            <h3>Quick Actions</h3>

            <div className="quick-action-grid">

              <button>
                <span>⚡</span>
                Analyze System
              </button>

              <button>
                <span>⚙</span>
                Optimize Resources
              </button>

              <button>
                <span>📊</span>
                Generate Report
              </button>

            </div>

          </div>

        </div>


        {/* AI INSIGHTS */}
        <div className="insights-panel">

          <div className="panel-header">

            <div>
              <h2>AI Insights</h2>

              <p>
                Latest recommendations
              </p>
            </div>

            <span className="insight-count">
              3 New
            </span>

          </div>


          <div className="insight-item">

            <div className="insight-icon warning">
              ⚠
            </div>

            <div>
              <h3>Memory optimization recommended</h3>
              <p>user-service · 12 min ago</p>
            </div>

            <span>›</span>

          </div>


          <div className="insight-item">

            <div className="insight-icon success">
              ✓
            </div>

            <div>
              <h3>Database performance improved</h3>
              <p>payment-service · 25 min ago</p>
            </div>

            <span>›</span>

          </div>


          <div className="insight-item">

            <div className="insight-icon purple">
              ◈
            </div>

            <div>
              <h3>Scaling policy adjustment</h3>
              <p>inventory-service · 1 hr ago</p>
            </div>

            <span>›</span>

          </div>

        </div>

      </div>


      {/* ROOT CAUSE ANALYSIS */}
      <div className="root-cause-section">

        <div className="section-heading">

          <div className="section-heading-left">

            <div className="large-panel-icon purple-panel-icon">
              ⌕
            </div>

            <div>
              <h2>Root Cause Analysis</h2>

              <p>
                AI-powered analysis of infrastructure incidents
              </p>
            </div>

          </div>

          <button className="view-all-button">
            View All Incidents →
          </button>

        </div>


        {/* INCIDENT ANALYSIS CARD */}
        <div className="incident-analysis-card">

          <div className="incident-card-header">

            <div className="incident-title">

              <div className="incident-warning-icon">
                !
              </div>

              <div>
                <h3>Database connection timeout</h3>

                <p>
                  payment-service · Detected 10 minutes ago
                </p>
              </div>

            </div>

            <span className="high-severity">
              High Severity
            </span>

          </div>


          <div className="analysis-grid">

            {/* ROOT CAUSE */}
            <div className="analysis-column">

              <div className="analysis-label">
                <span className="label-icon red-label">!</span>
                ROOT CAUSE
              </div>

              <h4>
                Connection Pool Exhaustion
              </h4>

              <p>
                A sudden increase in traffic caused the database connection
                pool to reach its maximum capacity.
              </p>

              <div className="confidence-bar">

                <div className="confidence-top">
                  <span>AI Confidence</span>
                  <strong>94%</strong>
                </div>

                <div className="progress">
                  <div className="progress-fill"></div>
                </div>

              </div>

            </div>


            {/* CONTRIBUTING FACTORS */}
            <div className="analysis-column">

              <div className="analysis-label">
                <span className="label-icon orange-label">⚠</span>
                CONTRIBUTING FACTORS
              </div>

              <ul className="factor-list">

                <li>
                  <span>•</span>
                  Increased request traffic
                </li>

                <li>
                  <span>•</span>
                  Insufficient connection pool size
                </li>

                <li>
                  <span>•</span>
                  Slow database queries
                </li>

              </ul>

            </div>


            {/* RECOMMENDATION */}
            <div className="analysis-column recommendation-column">

              <div className="analysis-label">
                <span className="label-icon green-label">✓</span>
                RECOMMENDED ACTION
              </div>

              <h4>
                Increase Connection Pool
              </h4>

              <p>
                Increase maximum database connections from 100 to 200 and
                optimize slow queries.
              </p>

              <button className="apply-button">
                Apply Recommendation
              </button>

            </div>

          </div>

        </div>


        {/* SECOND INCIDENT */}
        <div className="incident-analysis-card second-incident">

          <div className="incident-card-header">

            <div className="incident-title">

              <div className="incident-warning-icon orange-warning">
                !
              </div>

              <div>
                <h3>High memory usage detected</h3>

                <p>
                  user-service · Detected 25 minutes ago
                </p>
              </div>

            </div>

            <span className="medium-severity">
              Medium Severity
            </span>

          </div>


          <div className="compact-analysis">

            <div>
              <span className="mini-label">
                ROOT CAUSE
              </span>

              <strong>
                Memory leak in application process
              </strong>
            </div>

            <div>
              <span className="mini-label">
                AI CONFIDENCE
              </span>

              <strong className="confidence-text">
                87%
              </strong>
            </div>

            <div>
              <span className="mini-label">
                STATUS
              </span>

              <span className="investigating-status">
                Investigating
              </span>
            </div>

            <button className="analyze-button">
              View Analysis →
            </button>

          </div>

        </div>

      </div>


      {/* SELF HEALING */}
      <div className="self-healing-section">

        <div className="section-heading">

          <div className="section-heading-left">

            <div className="large-panel-icon green-panel-icon">
              ⚙
            </div>

            <div>
              <h2>Self-Healing Actions</h2>

              <p>
                Automated recovery actions performed by ACOP
              </p>
            </div>

          </div>

          <span className="active-badge">
            ● Active
          </span>

        </div>


        <div className="healing-grid">

          <div className="healing-card">

            <div className="healing-card-top">
              <span className="healing-success">✓</span>
              <span className="completed-badge">Completed</span>
            </div>

            <h3>Pod restart executed</h3>

            <p>payment-service</p>

            <span className="healing-time">
              5 minutes ago
            </span>

          </div>


          <div className="healing-card">

            <div className="healing-card-top">
              <span className="healing-success">✓</span>
              <span className="completed-badge">Completed</span>
            </div>

            <h3>Auto-scaling triggered</h3>

            <p>user-service</p>

            <span className="healing-time">
              12 minutes ago
            </span>

          </div>


          <div className="healing-card">

            <div className="healing-card-top">
              <span className="healing-success">✓</span>
              <span className="completed-badge">Completed</span>
            </div>

            <h3>Memory limit adjusted</h3>

            <p>inventory-service</p>

            <span className="healing-time">
              28 minutes ago
            </span>

          </div>

        </div>

      </div>

    </div>
  );
}

export default AISRECopilot;