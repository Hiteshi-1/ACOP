import React from "react";
import {
  FileText,
  Download,
  Calendar,
  BarChart3,
} from "lucide-react";

import "./Reports.css";

const reports = [
  ["System Performance Report", "May 26, 2024", "Performance"],
  ["Security Operations Report", "May 25, 2024", "Security"],
  ["Incident Summary Report", "May 24, 2024", "Incidents"],
  ["Kubernetes Cluster Report", "May 23, 2024", "Kubernetes"],
];

function Reports() {
  return (
    <div className="reports-page">

      <div className="reports-header">
        <div>
          <h1>Reports</h1>
          <p>View and export operational reports</p>
        </div>

        <button className="generate-report">
          Generate Report
        </button>
      </div>

      <div className="report-metrics">

        <div>
          <BarChart3 />
          <span>Total Reports</span>
          <strong>24</strong>
        </div>

        <div>
          <FileText />
          <span>This Month</span>
          <strong>8</strong>
        </div>

        <div>
          <Calendar />
          <span>Last Generated</span>
          <strong>Today</strong>
        </div>

      </div>

      <div className="reports-list">

        <h2>Recent Reports</h2>

        {reports.map((report, index) => (

          <div className="report-row" key={index}>

            <div className="report-icon">
              <FileText size={20} />
            </div>

            <div className="report-info">
              <strong>{report[0]}</strong>
              <span>{report[1]} • {report[2]}</span>
            </div>

            <button className="download-btn">
              <Download size={16} />
              Download
            </button>

          </div>

        ))}

      </div>

    </div>
  );
}

export default Reports;