import React, { useState } from "react";
import {
  User,
  Bell,
  Shield,
  Palette,
  Save,
} from "lucide-react";

import "./Settings.css";

function Settings() {
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(true);

  return (
    <div className="settings-page">

      <div className="settings-header">
        <h1>Settings</h1>
        <p>Manage your ACOP platform preferences</p>
      </div>

      <div className="settings-layout">

        <div className="settings-menu">

          <button className="settings-selected">
            <User size={17} />
            Profile
          </button>

          <button>
            <Bell size={17} />
            Notifications
          </button>

          <button>
            <Shield size={17} />
            Security
          </button>

          <button>
            <Palette size={17} />
            Appearance
          </button>

        </div>

        <div className="settings-content">

          <h2>Profile Settings</h2>

          <label>Full Name</label>
          <input value="Aarti Admin" readOnly />

          <label>Email Address</label>
          <input value="aarti@acop.com" readOnly />

          <h2>Preferences</h2>

          <div className="setting-toggle">

            <div>
              <strong>Notifications</strong>
              <span>Receive system alerts and updates</span>
            </div>

            <input
              type="checkbox"
              checked={notifications}
              onChange={() =>
                setNotifications(!notifications)
              }
            />

          </div>

          <div className="setting-toggle">

            <div>
              <strong>Dark Mode</strong>
              <span>Use dark theme across ACOP</span>
            </div>

            <input
              type="checkbox"
              checked={darkMode}
              onChange={() =>
                setDarkMode(!darkMode)
              }
            />

          </div>

          <button className="save-settings">
            <Save size={16} />
            Save Changes
          </button>

        </div>

      </div>

    </div>
  );
}

export default Settings;