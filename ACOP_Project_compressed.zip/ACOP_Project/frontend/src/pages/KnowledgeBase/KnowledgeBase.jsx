import React from "react";
import {
  Search,
  BookOpen,
  FileText,
  Database,
  HelpCircle,
} from "lucide-react";

import "./KnowledgeBase.css";

const articles = [
  "How to CrashLoopBackOff in Kubernetes",
  "Database connection timeout - Troubleshooting",
  "High memory usage - Resolution steps",
];

function KnowledgeBase() {
  return (
    <div className="knowledge-page">

      <div className="knowledge-header">
        <div>
          <h1>Knowledge Base</h1>
          <p>Search documentation, runbooks and incidents</p>
        </div>
      </div>

      <div className="knowledge-search">
        <Search size={18} />
        <input placeholder="Search for runbooks, incidents, solutions..." />
      </div>

      <div className="knowledge-tabs">
        <button className="selected">All</button>
        <button>Runbooks</button>
        <button>Incidents</button>
        <button>Documents</button>
        <button>FAQs</button>
      </div>

      <div className="knowledge-layout">

        <div className="recommended">

          <h3>Recommended for you</h3>

          {articles.map((article, index) => (

            <div className="article" key={index}>

              <BookOpen size={18} />

              <div>
                <strong>{article}</strong>
                <span>Updated recently</span>
              </div>

            </div>

          ))}

        </div>

        <div className="popular-topics">

          <h3>Popular Topics</h3>

          <p>Pod Restart</p>
          <p>Memory Issues</p>
          <p>Database Errors</p>
          <p>High CPU Usage</p>
          <p>Network Issues</p>

        </div>

      </div>

    </div>
  );
}

export default KnowledgeBase;