import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

import "./Dashboard.css";

const chartData = [
  { time: "00:00", value: 42 },
  { time: "02:00", value: 55 },
  { time: "04:00", value: 38 },
  { time: "06:00", value: 62 },
  { time: "08:00", value: 48 },
  { time: "10:00", value: 70 },
  { time: "12:00", value: 42 },
  { time: "14:00", value: 58 },
  { time: "16:00", value: 46 },
  { time: "18:00", value: 75 },
  { time: "20:00", value: 52 },
  { time: "22:00", value: 68 },
  { time: "24:00", value: 42 },
];

const stats = [
  {
    title: "System Health",
    value: "98%",
    label: "Healthy",
    icon: "♥",
    color: "green",
  },
  {
    title: "Running Pods",
    value: "52",
    label: "All Running",
    icon: "⬡",
    color: "blue",
  },
  {
    title: "Active Alerts",
    value: "3",
    label: "View Alerts",
    icon: "▲",
    color: "red",
  },
  {
    title: "Predicted Failures",
    value: "2",
    label: "View Predictions",
    icon: "♣",
    color: "purple",
  },
  {
    title: "Security Threats",
    value: "1",
    label: "View Threats",
    icon: "⬟",
    color: "purple",
  },
];

const charts = [
  {
    title: "CPU Usage",
    value: "42%",
    color: "#38bdf8",
  },
  {
    title: "Memory Usage",
    value: "68%",
    color: "#4ade80",
  },
  {
    title: "Network I/O",
    value: "32%",
    color: "#c084fc",
  },
  {
    title: "Storage Usage",
    value: "74%",
    color: "#fbbf24",
  },
];

const incidents = [
  {
    incident: "Database connection timeout",
    severity: "High",
    status: "Resolved",
    time: "10 min ago",
    service: "payment-service",
  },
  {
    incident: "High memory usage detected",
    severity: "Medium",
    status: "Investigating",
    time: "25 min ago",
    service: "user-service",
  },
  {
    incident: "Pod restarted automatically",
    severity: "Low",
    status: "Resolved",
    time: "1 hr ago",
    service: "inventory-service",
  },
];

const activities = [
  ["Auto scaling triggered for user-service", "5 min ago"],
  ["Pod restart executed for payment-service", "11 min ago"],
  ["Backup completed for database", "30 min ago"],
  ["Security scan completed", "1 hr ago"],
];

function Dashboard() {
  return (
    <main className="dashboard-page">

      {/* HEADER */}
      <section className="dashboard-top">
        <div>
          <h1>Dashboard</h1>
          <p>Overview of your cloud environment</p>
        </div>

        <div className="dashboard-controls">
          <button>Last 24 Hours⌄</button>
          <button className="refresh-btn">↻</button>
        </div>
      </section>

      {/* KPI CARDS */}
      <section className="stats-grid">
        {stats.map((stat) => (
          <div className="stat-card" key={stat.title}>
            <div className={`stat-icon ${stat.color}`}>
              {stat.icon}
            </div>

            <div className="stat-content">
              <h3>{stat.title}</h3>
              <div className="stat-value">{stat.value}</div>
              <div className={`stat-label ${stat.color}`}>
                {stat.label}
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* CHARTS */}
      <section className="charts-grid">
        {charts.map((chart) => (
          <div className="chart-card" key={chart.title}>

            <div className="chart-header">
              <h3>{chart.title}</h3>

              <strong style={{ color: chart.color }}>
                {chart.value}
              </strong>
            </div>

            <div className="chart-container">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>

                  <CartesianGrid
                    stroke="#334155"
                    strokeDasharray="4 4"
                  />

                  <XAxis
                    dataKey="time"
                    stroke="#64748b"
                    tick={{ fontSize: 10 }}
                  />

                  <YAxis
                    domain={[0, 100]}
                    stroke="#64748b"
                    tick={{ fontSize: 10 }}
                  />

                  <Tooltip />

                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke={chart.color}
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 4 }}
                  />

                </LineChart>
              </ResponsiveContainer>
            </div>

          </div>
        ))}
      </section>

      {/* BOTTOM */}
      <section className="bottom-grid">

        {/* INCIDENTS */}
        <div className="panel-card">

          <div className="panel-header">
            <div>
              <h2>Recent Incidents</h2>
              <p>Manage and monitor recent incidents</p>
            </div>

            <button className="view-all">
              View All
            </button>
          </div>

          <div className="table-wrapper">
            <table className="incidents-table">
              <thead>
                <tr>
                  <th>Incident</th>
                  <th>Severity</th>
                  <th>Status</th>
                  <th>Time</th>
                  <th>Service</th>
                </tr>
              </thead>

              <tbody>
                {incidents.map((item) => (
                  <tr key={item.incident}>
                    <td>{item.incident}</td>

                    <td>
                      <span className={`badge ${item.severity.toLowerCase()}`}>
                        {item.severity}
                      </span>
                    </td>

                    <td>
                      <span
                        className={`badge ${item.status
                          .toLowerCase()
                          .replace(" ", "-")}`}
                      >
                        {item.status}
                      </span>
                    </td>

                    <td>{item.time}</td>
                    <td>{item.service}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>

        {/* ACTIVITIES */}
        <div className="panel-card">

          <div className="panel-header">
            <div>
              <h2>Recent Activities</h2>
              <p>Latest system activities</p>
            </div>
          </div>

          <div className="activities-list">
            {activities.map(([text, time]) => (
              <div className="activity-item" key={text}>

                <span className="activity-icon">✓</span>

                <span className="activity-text">
                  {text}
                </span>

                <span className="activity-time">
                  {time}
                </span>

              </div>
            ))}
          </div>

        </div>

      </section>

    </main>
  );
}

export default Dashboard;