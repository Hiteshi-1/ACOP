import React from "react";

function AICodeDebugger() {
  return (
    <div
      style={{
        minHeight: "100vh",
        width: "100%",
        padding: "40px",
        background: "#0b1020",
        color: "#ffffff",
        boxSizing: "border-box",
      }}
    >
      <h1 style={{ color: "#ffffff", fontSize: "40px" }}>
        AI Code Debugger
      </h1>

      <p style={{ color: "#94a3b8", fontSize: "18px" }}>
        Upload your project and let ACOP detect and solve code errors.
      </p>

      <div
        style={{
          marginTop: "30px",
          padding: "40px",
          background: "#111c32",
          border: "2px solid #304568",
          borderRadius: "16px",
        }}
      >
        <h2 style={{ color: "#ffffff" }}>
          Upload Project Folder
        </h2>

        <input
          type="file"
          webkitdirectory=""
          directory=""
          multiple
          style={{
            display: "block",
            marginTop: "20px",
            color: "#ffffff",
            fontSize: "16px",
          }}
        />

        <button
          style={{
            marginTop: "25px",
            padding: "15px 30px",
            background: "#2563eb",
            color: "#ffffff",
            border: "none",
            borderRadius: "10px",
            fontSize: "16px",
          }}
        >
          Analyze Project
        </button>
      </div>
    </div>
  );
}

export default AICodeDebugger;