import React from "react";
import {
  Boxes,
  Play,
  Clock,
  XCircle,
  RotateCcw,
  FileText,
} from "lucide-react";

import "./Kubernetes.css";

const pods = [
  {
    name: "payment-service-7d98d",
    namespace: "default",
    status: "Running",
    restarts: 0,
    cpu: "32%",
    memory: "45%",
  },
  {
    name: "user-service-07d08",
    namespace: "default",
    status: "Running",
    restarts: 1,
    cpu: "28%",
    memory: "38%",
  },
  {
    name: "order-service-6g8h8",
    namespace: "default",
    status: "Running",
    restarts: 0,
    cpu: "18%",
    memory: "30%",
  },
  {
    name: "inventory-service-7b0n9",
    namespace: "default",
    status: "Running",
    restarts: 0,
    cpu: "22%",
    memory: "40%",
  },
  {
    name: "auth-service-6h73",
    namespace: "default",
    status: "Restarting",
    restarts: 3,
    cpu: "15%",
    memory: "25%",
  },
];

function Kubernetes() {
  return (
    <div className="kubernetes-page">

      {/* HEADER */}

      <div className="kubernetes-header">

        <div>
          <h1>Kubernetes</h1>
          <p>Manage your Kubernetes cluster</p>
        </div>

        <button className="deploy-btn">
          Deploy New
        </button>

      </div>

      {/* METRIC CARDS */}

      <div className="kubernetes-stats">

        <div className="kube-stat">
          <div className="kube-icon blue">
            <Boxes size={22} />
          </div>

          <div>
            <span>Total Pods</span>
            <strong>52</strong>
          </div>
        </div>

        <div className="kube-stat">
          <div className="kube-icon green">
            <Play size={22} />
          </div>

          <div>
            <span>Running</span>
            <strong>48</strong>
          </div>
        </div>

        <div className="kube-stat">
          <div className="kube-icon orange">
            <Clock size={22} />
          </div>

          <div>
            <span>Pending</span>
            <strong>2</strong>
          </div>
        </div>

        <div className="kube-stat">
          <div className="kube-icon purple">
            <XCircle size={22} />
          </div>

          <div>
            <span>Failed</span>
            <strong>2</strong>
          </div>
        </div>

      </div>

      {/* TABLE */}

      <div className="pods-table-card">

        <table>

          <thead>
            <tr>
              <th>Pod Name</th>
              <th>Namespace</th>
              <th>Status</th>
              <th>Restarts</th>
              <th>CPU</th>
              <th>Memory</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>

            {pods.map((pod) => (

              <tr key={pod.name}>

                <td>{pod.name}</td>

                <td>{pod.namespace}</td>

                <td>
                  <span
                    className={
                      pod.status === "Running"
                        ? "status running"
                        : "status restarting"
                    }
                  >
                    {pod.status}
                  </span>
                </td>

                <td>{pod.restarts}</td>

                <td>{pod.cpu}</td>

                <td>{pod.memory}</td>

                <td>

                  <div className="action-buttons">

                    <button title="Restart Pod">
                      <RotateCcw size={16} />
                    </button>

                    <button title="View Logs">
                      <FileText size={16} />
                    </button>

                    <button title="Pod Details">
                      <Boxes size={16} />
                    </button>

                  </div>

                </td>

              </tr>

            ))}

          </tbody>

        </table>

      </div>

    </div>
  );
}

export default Kubernetes;