import React from "react";
import {
  Shield,
  AlertTriangle,
  Bug,
  CheckCircle,
  Lock,
  Eye,
} from "lucide-react";

import "./SecurityCenter.css";

const threats = [
  {
    name: "Brute force attack detected",
    severity: "High",
    status: "Active",
    source: "192.168.1.10",
    time: "5 min ago",
  },
  {
    name: "Malware detected in container",
    severity: "High",
    status: "Active",
    source: "pod: evil-pod",
    time: "15 min ago",
  },
  {
    name: "Unauthorized login attempt",
    severity: "Medium",
    status: "Investigating",
    source: "10.0.0.5",
    time: "25 min ago",
  },
];

function SecurityCenter() {
  return (
    <div className="security-page">

      {/* HEADER */}

      <div className="security-header">

        <div>
          <h1>Security Operations Center</h1>

          <p>
            Monitor and respond to security threats
          </p>
        </div>

        <button className="security-action">
          View All Threats
        </button>

      </div>

      {/* SECURITY METRICS */}

      <div className="security-metrics">

        <div className="security-card">

          <div className="security-icon orange">
            <Shield size={22} />
          </div>

          <div>
            <span>Threat Level</span>
            <strong>Medium</strong>
          </div>

        </div>

        <div className="security-card">

          <div className="security-icon blue">
            <Lock size={22} />
          </div>

          <div>
            <span>Total Threats</span>
            <strong>12</strong>
          </div>

        </div>

        <div className="security-card">

          <div className="security-icon red">
            <AlertTriangle size={22} />
          </div>

          <div>
            <span>Active Threats</span>
            <strong>3</strong>
          </div>

        </div>

        <div className="security-card">

          <div className="security-icon green">
            <CheckCircle size={22} />
          </div>

          <div>
            <span>Resolved Threats</span>
            <strong>9</strong>
          </div>

        </div>

      </div>

      {/* THREAT TABLE */}

      <div className="threat-table-card">

        <table>

          <thead>
            <tr>
              <th>Threat</th>
              <th>Severity</th>
              <th>Status</th>
              <th>Source</th>
              <th>Time</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>

            {threats.map((threat, index) => (

              <tr key={index}>

                <td>{threat.name}</td>

                <td>
                  <span
                    className={`threat-severity ${threat.severity.toLowerCase()}`}
                  >
                    {threat.severity}
                  </span>
                </td>

                <td>
                  <span
                    className={`threat-status ${threat.status.toLowerCase()}`}
                  >
                    {threat.status}
                  </span>
                </td>

                <td>{threat.source}</td>

                <td>{threat.time}</td>

                <td>

                  <div className="security-actions">

                    <button title="View Threat">
                      <Eye size={16} />
                    </button>

                    <button title="Investigate">
                      <Bug size={16} />
                    </button>

                  </div>

                </td>

              </tr>

            ))}

          </tbody>

        </table>

      </div>

    </div>
  );
}

export default SecurityCenter;