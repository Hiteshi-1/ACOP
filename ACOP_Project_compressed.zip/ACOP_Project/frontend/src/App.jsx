// src/App.jsx
import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Layout from "./components/layout/Layout";

import Dashboard from "./pages/Dashboard";
import Kubernetes from "./pages/Kubernetes/Kubernetes";
import AISRECopilot from "./pages/AISRECopilot/AISRECopilot";
import SecurityCenter from "./pages/SecurityCenter/SecurityCenter";
import Incidents from "./pages/Incidents/Incidents";
import PredictiveFailures from "./pages/PredictiveFailures/PredictiveFailures";
import Reports from "./pages/Reports/Reports";
import Settings from "./pages/Settings/Settings";
import KnowledgeBase from "./pages/KnowledgeBase/KnowledgeBase";
import AICodeDebugger from "./pages/AICodeDebugger/AICodeDebugger";
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Navigate to="/dashboard" replace />} />

          <Route path="dashboard" element={<Dashboard />} />
          {/* AI SRE Copilot */}
          <Route path="ai-sre-copilot" element={<AISRECopilot />}/>
          <Route path="kubernetes" element={<Kubernetes />} />
          <Route path="ai-code-debugger"element={<AICodeDebugger />}/>
          <Route path="security" element={<SecurityCenter />} />
          <Route path="incidents" element={<Incidents />} />
          <Route
            path="predictive-failures"
            element={<PredictiveFailures />}
          />
          <Route path="reports" element={<Reports />} />
          <Route path="settings" element={<Settings />} />
          <Route path="knowledge-base" element={<KnowledgeBase />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;